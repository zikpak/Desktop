package org.fog.test.perfeval;

import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Method;
import java.util.Arrays;

public class TestWifiSystem {

    WifiSystem system;
    @Before
    public void createSystem(){
        system = new WifiSystem();
    }

    @Test
    public void createRequest() {

        try {
            Method method = WifiSystem.class.getDeclaredMethod("createFogDevice", String.class, Long.class, Integer.class, Long.class, Long.class, Integer.class, Double.class, Double.class, Double.class);
            method.setAccessible(true);


//        system.setFogRates(Arrays.asList(
//                method.invoke("rate-1", 30000, 40000, 100, 10000, 0, 0.01, 16*103, 16*83.25),
//                system.createFogDevice("rate-2", 40000, 50000, 100, 10000, 0, 0.01, 16*103, 16*83.25),
//                system.createFogDevice("rate-3", 50000, 55000, 100, 10000, 0, 0.01, 16*103, 16*83.25)));

        system.setUsers(Arrays.asList(
                new User(new UserRequest(34900,44000)),
                new User(new UserRequest(45000,35000)),
                new User(new UserRequest(47800,70000))));


        } catch (Exception e){
            e.printStackTrace();
        }
    }
}
