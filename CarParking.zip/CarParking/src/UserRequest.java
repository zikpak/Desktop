package org.fog.test.perfeval;

public class UserRequest {

    private int mips;
    private int ram;

    public UserRequest(int mips, int ram){
        this.mips=mips;
        this.ram=ram;
    }

    public int getMips() {
        return mips;
    }

    public int getRam() {
        return ram;
    }

}
