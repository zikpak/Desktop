package org.fog.test.perfeval;

import org.fog.entities.FogDevice;

public class User {

    private UserRequest userRequest;

    public User(UserRequest userRequest){
        this.userRequest=userRequest;
    }

    public UserRequest getUserRequest() {
        return userRequest;
    }

    public void setUserRequest(UserRequest userRequest) {
        this.userRequest = userRequest;
    }

    public void checkChoise(FogDevice fogDevice){
    }
}
