package org.fog.test.perfeval;

import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.power.PowerHost;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;
import org.cloudbus.cloudsim.sdn.overbooking.BwProvisionerOverbooking;
import org.cloudbus.cloudsim.sdn.overbooking.PeProvisionerOverbooking;
import org.fog.entities.FogBroker;
import org.fog.entities.FogDevice;
import org.fog.entities.FogDeviceCharacteristics;
import org.fog.placement.Controller;
import org.fog.placement.ModuleMapping;
import org.fog.policy.AppModuleAllocationPolicy;
import org.fog.scheduler.StreamOperatorScheduler;
import org.fog.utils.FogLinearPowerModel;
import org.fog.utils.FogUtils;
import org.fog.utils.TimeKeeper;

import java.util.*;

public class WifiSystem {

    static List<User> users = new ArrayList<User>();

    static List<FogDevice> fogRates = new ArrayList<FogDevice>();

    static List<FogDevice> fogDevices = new ArrayList<FogDevice>();

    private static boolean CLOUD = false;


    public static void main(String[] args) {

        Log.printLine("Starting wireless system...");

        try {
            Log.disable();
            int num_user = 1; // number of cloud users
            boolean trace_flag = false; // mean trace events
            Calendar calendar = Calendar.getInstance();

            CloudSim.init(num_user, calendar, trace_flag);

            String appId = "dcns"; // identifier of the application

            FogBroker broker = new FogBroker("broker");

            createFogDevices(broker.getId(), appId);

            users = Arrays.asList(
                    new User(new UserRequest(40000, 60000)),
                    new User(new UserRequest(46000, 39000)),
                    new User(new UserRequest(47800, 70000)));

            fogRates = Arrays.asList(
                    createFogDevice("rate-1", 30000, 40000, 100, 10000, 0, 0.01, 16 * 103, 16 * 83.25),
                    createFogDevice("rate-2", 40000, 50000, 100, 10000, 0, 0.01, 16 * 103, 16 * 83.25),
                    createFogDevice("rate-3", 50000, 60000, 100, 10000, 0, 0.01, 16 * 103, 16 * 83.25));

            checkChoice();

            Controller controller = null;

            ModuleMapping moduleMapping = ModuleMapping.createModuleMapping(); // initializing a module mapping

            TimeKeeper.getInstance().setSimulationStartTime(Calendar.getInstance().getTimeInMillis());

            CloudSim.startSimulation();

            CloudSim.stopSimulation();

            Log.printLine("VRGame finished!");
        } catch (Exception e) {
            e.printStackTrace();
            Log.printLine("Unwanted errors happen");
        }
    }

    /**
     * Creates the fog devices in the physical topology of the simulation.
     *
     * @param userId user ID
     * @param appId  app ID
     */
    private static void createFogDevices(int userId, String appId) {
        FogDevice cloud = createFogDevice("cloud", 44800, 40000, 100, 10000, 0, 0.01, 16 * 103, 16 * 83.25);
        cloud.setParentId(-1);
        fogDevices.add(cloud);
        FogDevice proxy = createFogDevice("proxy-server", 2800, 4000, 10000, 10000, 1, 0.0, 107.339, 83.4333);
        proxy.setParentId(cloud.getId());
        proxy.setUplinkLatency(100); // latency of connection between proxy server and cloud is 100 ms
        fogDevices.add(proxy);
    }

    /**
     * Creates a vanilla fog device
     *
     * @param nodeName    name of the device to be used in simulation
     * @param mips        MIPS
     * @param ram         RAM
     * @param upBw        uplink bandwidth
     * @param downBw      downlink bandwidth
     * @param level       hierarchy level of the device
     * @param ratePerMips cost rate per MIPS used
     * @param busyPower   busy power
     * @param idlePower   idle power
     * @return Fog Device
     */
    private static FogDevice createFogDevice(String nodeName, long mips,
                                             int ram, long upBw, long downBw, int level, double ratePerMips, double busyPower, double idlePower) {

        List<Pe> peList = new ArrayList<Pe>();

        // 3. Create PEs and add these into a list.
        peList.add(new Pe(0, new PeProvisionerOverbooking(mips))); // need to store Pe id and MIPS Rating

        int hostId = FogUtils.generateEntityId();
        long storage = 1000000; // host storage
        int bw = 10000;

        PowerHost host = new PowerHost(
                hostId,
                new RamProvisionerSimple(ram),
                new BwProvisionerOverbooking(bw),
                storage,
                peList,
                new StreamOperatorScheduler(peList),
                new FogLinearPowerModel(busyPower, idlePower)
        );

        List<Host> hostList = new ArrayList<Host>();
        hostList.add(host);

        String arch = "x86"; // system architecture
        String os = "Linux"; // operating system
        String vmm = "Xen";

        double time_zone = 10.0; // time zone this resource located
        double cost = 3.0; // the cost of using processing in this resource
        double costPerMem = 0.05; // the cost of using memory in this resource
        double costPerStorage = 0.001; // the cost of using storage in this
        // resource
        double costPerBw = 0.0; // the cost of using bw in this resource

        LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are not adding SAN
        // devices by now

        FogDeviceCharacteristics characteristics = new FogDeviceCharacteristics(
                arch, os, vmm, host, time_zone, cost, costPerMem,
                costPerStorage, costPerBw);

        FogDevice fogdevice = null;
        try {
            fogdevice = new FogDevice(nodeName, characteristics,
                    new AppModuleAllocationPolicy(hostList), storageList, 10, upBw, downBw, 0, ratePerMips);
        } catch (Exception e) {
            e.printStackTrace();
        }

        assert fogdevice != null;
        fogdevice.setLevel(level);
        return fogdevice;
    }

    public static void checkChoice() {

        List<FogDevice> usesFogRates = new ArrayList<FogDevice>();

        for (int i = 0; i < users.size(); i++) {

            List<FogDevice> allFogRates = new ArrayList<FogDevice>();

            List<FogDevice> otherFogRates = new ArrayList<FogDevice>();

            List<FogDevice> bestFogRates = new ArrayList<FogDevice>();

            //0 mips, 1 ram, 2 storage
            int[] params = {users.get(i).getUserRequest().getMips(),
                    users.get(i).getUserRequest().getRam()};
            int[] id = {0, 0}; //0 mips, 1 ram, 2 storage

            for (int k = 0; k < fogRates.size(); k++) {
                if (Math.abs(users.get(i).getUserRequest().getMips() - fogRates.get(k).getHost().getTotalMips()) < params[0]) {
                    params[0] = (int) Math.abs(users.get(i).getUserRequest().getMips() - fogRates.get(k).getHost().getTotalMips());
                    id[0] = k;
                }

                if (Math.abs(users.get(i).getUserRequest().getRam() - fogRates.get(k).getHost().getRam()) < params[1]) {
                    params[1] = Math.abs(users.get(i).getUserRequest().getRam() - fogRates.get(k).getHost().getRam());
                    id[1] = k;
                }

                if (params[0] == Math.abs(users.get(i).getUserRequest().getMips() - fogRates.get(k).getHost().getTotalMips()) && params[1] == Math.abs(users.get(i).getUserRequest().getRam() - fogRates.get(k).getHost().getRam())) {
                    bestFogRates.add(fogRates.get(k));
                } else {
                    otherFogRates.add(fogRates.get(k));
                }
            }

            Collections.reverse(otherFogRates);
            Collections.reverse(bestFogRates);

            allFogRates.addAll(bestFogRates);

            allFogRates.addAll(otherFogRates);

            for (FogDevice fogDevice : allFogRates) {
                System.out.println(fogDevice.getName());
            }
            usesFogRates.add(allFogRates.get(0));

            System.out.println("The best choice for user #" + i + " is " + usesFogRates.get(i).getName());
        }
    }

    public void setUsers(List<User> users) {
        WifiSystem.users = users;
    }

    public List<User> getUsers() {
        return users;
    }

    public void setFogRates(List<FogDevice> fogRates) {
        fogRates = fogRates;
    }

    public List<FogDevice> getFogRates() {
        return fogRates;
    }
}

//    public static void main(String[] args){
//        List<test> users = Arrays.asList(new test(30000, 35000, null),new test(35000, 50000, null));
//        List<test> fogs = Arrays.asList(new test(32000, 50000),new test(35000, 45000));
//
//        for(int i = 0; i<users.size(); i++) {
//            int[] params = {(int) users.get(i).mipsR, users.get(i).ramR}; //0 mips, 1 ram
//            int[] id = {0,0}; //0 mips, 1 ram
//
//            for(int k = 0; k<fogs.size(); k++) {
//                if(Math.abs(users.get(i).mipsR-fogs.get(k).mips)<params[0]) {
//                    params[0]=(int) Math.abs(users.get(i).mipsR-fogs.get(k).mips);
//                    id[0]=k;
//                    System.out.println("Mips "+Math.abs(users.get(i).mipsR-fogs.get(k).mips));
//                }
//
//                if(Math.abs(users.get(i).ramR-fogs.get(k).ram)<params[1]) {
//                    params[1]=Math.abs(users.get(i).ramR-fogs.get(k).ram);
//                    id[1]=k;
//                    System.out.println("Ram "+Math.abs(users.get(i).ramR-fogs.get(k).ram));
//                }
//
//            }
//            System.out.println("For user #"+i+" the best choice will be fog "+id[0]+" "+id[1]);
//        }
//    }